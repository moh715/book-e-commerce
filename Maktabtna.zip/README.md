
### Online Bookstore System: A Project Overview

So, for this project, we're looking at an online bookstore. It's a web platform where people can browse for books, buy them, and keep track of their orders. The system is built around three main types of users: the customers, the site administrators, and an external payment gateway, each one has their own role and way of interacting with the platform.

First, you've got the customers. To buy anything, they need to create an account and log in. Once they're in, they can search for books, throw them into a shopping cart, and go through the checkout process. After buying something, they can also see where their order is and leave reviews for books they've read. Then there are the admins. They're the ones working behind the scenes, managing the whole platform. They don't use the website the way a customer does; instead, they have a backend system to update the book inventory, handle customer orders, and manage user accounts. For payments, the system uses an outside payment gateway. When a customer checks out, the bookstore platform connects to this gateway to securely process the transaction. The gateway just does its job and doesn't start any actions on its own. Oh, and the system also has a cool feature: book recommendations. Based on what a customer has bought and reviewed in the past, the system automatically suggests other books they might like when they're browsing. It's all built into the browsing experience, so the customer doesn't have to do anything extra.

### Use Case Diagram

To show what the system is supposed to do, we created a Use Case Diagram. It basically maps out who can do what. The customers are the busiest ones here. They can register and log in, browse books, add them to their cart, and check out. Checking out involves making a payment, which is where the payment gateway comes in with its own 'process payment' function. Customers can also track their orders and leave reviews. We even showed that leaving a review is an extra step that can happen after they track an order. The admins have their own separate set of tasks, all about managing the platform. After they log in, they can manage the inventory, oversee orders, and handle user accounts. These tasks are totally separate from the customer side of things. The payment gateway is only involved in that one 'process payment' task, which is a necessary part of the customer's 'make payment' action during checkout.

### Activity Diagram: Buying a Book

We also made an Activity Diagram to map out the step-by-step flow of what happens when a customer buys a book. It starts with the customer browsing or searching for a book. When they find one they like and view the details, they have the option to add it to their cart. If they click "add," the system first checks if they're logged in. If they aren't, it sends them to a login or registration page before actually adding the book. Once they're logged in, the book goes into their cart. From there, they can either keep shopping (which loops back to browsing) or head to checkout.

When they choose to checkout, they need to enter a shipping address, pick a payment method, and put in their payment details. The system then validates that information. If something's wrong, like an incorrect card number, it shows an error message and asks them to try again. If the payment info is correct, the order is processed, they get a confirmation email, and the system sets it up so they can track their order from that point on. That's where the whole process ends.



### Online Bookstore System: A Project Overview

The Online Bookstore and Recommendation System is a web-based platform designed to facilitate seamless book browsing, purchasing, and personalized discovery. It connects customers, sellers, and administrators to create an efficient digital marketplace for books.

Customers must register and log in using their credentials. Once logged in, they can browse available books by category, author, or genre, add items to their cart, and proceed to checkout. Customers can leave reviews and ratings for purchased books, track their order history, and manage their profile details such as password and contact information. If the provided information is invalid, the system prompts them to re-enter correct details.

The recommendation engine analyzes each customer's purchase history, browsing behavior, and ratings to generate personalized book suggestions. Customers receive recommendations on their homepage and via email notifications. They can also explore curated lists such as bestsellers, new arrivals, and trending titles.

Sellers must register and log into the system. They can list books with full details (title, author, genre, price, and stock quantity), manage their inventory, and update pricing. Sellers receive notifications about new orders and update order statuses accordingly. They can also respond to customer reviews.

Administrators manage the overall system, ensuring smooth and secure operation. They handle user account management, monitor transactions, resolve disputes, and ensure compliance with platform policies. Administrators can suspend or remove fraudulent accounts and oversee the recommendation algorithm's performance.



